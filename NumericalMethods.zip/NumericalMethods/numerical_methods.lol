\contentsline {listing}{\numberline {1}{\ignorespaces Invertibilidade de matriz 2x2}}{14}{listing.1}%
\contentsline {listing}{\numberline {2}{\ignorespaces Soma parcial da série \(1/n\) de 1 até 10.}}{15}{listing.2}%
\contentsline {listing}{\numberline {3}{\ignorespaces Produto escalar simples de vetores. }}{15}{listing.3}%
\contentsline {listing}{\numberline {4}{\ignorespaces Método da bisseção simples}}{16}{listing.4}%
\contentsline {listing}{\numberline {5}{\ignorespaces Controle de fluxo}}{17}{listing.5}%
\contentsline {listing}{\numberline {6}{\ignorespaces Algoritmo de Euclides (MDC, recursivo)}}{17}{listing.6}%
\contentsline {listing}{\numberline {7}{\ignorespaces Detectar se número é perfeito}}{18}{listing.7}%
\contentsline {listing}{\numberline {8}{\ignorespaces Aproximação de \(\pi \)}}{19}{listing.8}%
\contentsline {listing}{\numberline {9}{\ignorespaces Convergência de uma sequência iterativa}}{20}{listing.9}%
\contentsline {listing}{\numberline {10}{\ignorespaces Testagem de ortogonalidade de vetores.}}{21}{listing.10}%
\contentsline {listing}{\numberline {11}{\ignorespaces Verificar se é primo.}}{22}{listing.11}%
\contentsline {listing}{\numberline {12}{\ignorespaces Soma da série.}}{22}{listing.12}%
\contentsline {listing}{\numberline {13}{\ignorespaces Fatorial usando \texttt {while}.}}{22}{listing.13}%
\contentsline {listing}{\numberline {14}{\ignorespaces Contar elementos positivos de um vetor.}}{23}{listing.14}%
\contentsline {listing}{\numberline {15}{\ignorespaces Média das Notas}}{25}{listing.15}%
\contentsline {listing}{\numberline {16}{\ignorespaces Criando arrays a partir de listas.}}{28}{listing.16}%
\contentsline {listing}{\numberline {17}{\ignorespaces Criando arrays pelo numpy.}}{28}{listing.17}%
\contentsline {listing}{\numberline {18}{\ignorespaces Calculando a Distância entre Dois Pontos}}{47}{listing.18}%
\contentsline {listing}{\numberline {19}{\ignorespaces Subrotina: formatar o código de um boletim.}}{48}{listing.19}%
\contentsline {listing}{\numberline {20}{\ignorespaces Calculo de Determinante Sensível a Erro}}{49}{listing.20}%
\contentsline {listing}{\numberline {21}{\ignorespaces Criação de módulo no Colab}}{50}{listing.21}%
\contentsline {listing}{\numberline {22}{\ignorespaces \textbf {Redes Sociais:} Motor de Matrizes}}{57}{listing.22}%
\contentsline {listing}{\numberline {23}{\ignorespaces \textbf {Redes Sociais:} Algoritmo da Rede Social}}{58}{listing.23}%
\contentsline {listing}{\numberline {24}{\ignorespaces \textbf {Redes Sociais:} Interface de Usuário}}{59}{listing.24}%
\contentsline {listing}{\numberline {25}{\ignorespaces \textbf {Redes Sociais:} Painel de Testes}}{60}{listing.25}%
\contentsline {listing}{\numberline {26}{\ignorespaces Barras, Scatterplots e Histograma}}{69}{listing.26}%
\contentsline {listing}{\numberline {27}{\ignorespaces Rodando Vetores}}{73}{listing.27}%
\contentsline {listing}{\numberline {28}{\ignorespaces Pedidos de um Meteorologista}}{75}{listing.28}%
\contentsline {listing}{\numberline {29}{\ignorespaces Calculando a Variância}}{92}{listing.29}%
\contentsline {listing}{\numberline {30}{\ignorespaces Implementação do Método LU}}{100}{listing.30}%
\contentsline {listing}{\numberline {31}{\ignorespaces Método de Cholesky em Python}}{112}{listing.31}%
\contentsline {listing}{\numberline {32}{\ignorespaces Método da Eliminação de Gauss em Python}}{120}{listing.32}%
\contentsline {listing}{\numberline {33}{\ignorespaces Eliminação de Gauss: matriz pós Pivôs}}{122}{listing.33}%
\contentsline {listing}{\numberline {34}{\ignorespaces Método de Gauss-Jacobi em Python}}{127}{listing.34}%
\contentsline {listing}{\numberline {35}{\ignorespaces Método de Gauss-Seidel em Python}}{129}{listing.35}%
\contentsline {listing}{\numberline {36}{\ignorespaces Método dos Gradientes em Python}}{132}{listing.36}%
\contentsline {listing}{\numberline {37}{\ignorespaces Método QR Clássico e Modificado}}{137}{listing.37}%
\contentsline {listing}{\numberline {38}{\ignorespaces Retro-substituição em Python}}{141}{listing.38}%
\contentsline {listing}{\numberline {39}{\ignorespaces Determinantes e Inversas com Matriz QR}}{143}{listing.39}%
\contentsline {listing}{\numberline {40}{\ignorespaces Implementação do Método de Francis e Comparações}}{146}{listing.40}%
\contentsline {listing}{\numberline {41}{\ignorespaces Método da Potência com critério de parada}}{157}{listing.41}%
\contentsline {listing}{\numberline {42}{\ignorespaces Implementação do Método da PotÊncia Inversa}}{159}{listing.42}%
